/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsclientfornaro;

/**
 *
 * @author ale
 */
public class WsClientFornaro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String username, password;
        
        username="prova";
        password="prova";
        System.out.println("PROVO LOGIN CON username: prova - psw: prova");
                
        boolean loginResult = login(username, password);
        System.out.println("Ho richiesto il WS login");
        
        if(loginResult)
            System.out.println("Login eseguito.");
        else
            System.out.println("Login fallito!");
    }

    private static boolean login(java.lang.String username, java.lang.String password) {
        jm.wsfornaro.Usermanager_Service service = new jm.wsfornaro.Usermanager_Service();
        jm.wsfornaro.Usermanager port = service.getUsermanagerPort();
        return port.login(username, password);
    }
    
}
