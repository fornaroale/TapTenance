package jm.taptenance_fornaro;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class MainActivity extends Activity {

    String username, password;
    ProgressDialog pdialog;
    SoapObject request;
    SoapPrimitive risLogin;

    private final String METHOD_NAME = "login";
    private final String SOAP_ACTION = "http://wsfornaro.jm/usermanager/loginRequest"; // dubbio!
    private final String NAMESPACE = "http://wsfornaro.jm/";
    private final String SOAP_URL = "http://localhost:8080/webappFornaro/usermanager";

    private EditText etUsername;
    private EditText etPassword;
    private Button bLogin;
    private TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = (EditText) findViewById(R.id.edUsername);
        etPassword = (EditText) findViewById(R.id.edPassword);
        bLogin = (Button)findViewById(R.id.loginButton);
        tvRegister = (TextView) findViewById(R.id.tvCreaAccount);

        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            username = etUsername.getText().toString();
            password = etPassword.getText().toString();

            // Metodo locale per contattare Web Service
            LoginClass login = new LoginClass();
            login.execute();
            }
        });

        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(intent);
            }
        });
    }

    private class LoginClass extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            request = new SoapObject(NAMESPACE, METHOD_NAME);
            request.addProperty("username", username);
            request.addProperty("password", password);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE httpTransport = new HttpTransportSE(SOAP_URL);
            try {
                httpTransport.call(SOAP_ACTION, envelope);
                SoapPrimitive risLogin = (SoapPrimitive) envelope.getResponse();
                Log.wtf("risultato login: ", risLogin.toString());
            } catch (Exception e) {
                e.getMessage();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            pdialog.dismiss();
            Toast.makeText(getApplicationContext(), "Risultato login: " + risLogin.toString(), Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pdialog = new ProgressDialog(MainActivity.this);
            pdialog.setMessage("Aspetta...");
            pdialog.show();
        }
    }
}